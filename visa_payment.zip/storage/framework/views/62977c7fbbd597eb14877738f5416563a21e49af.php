<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Payment Details - UKVI</title>
        <link rel="icon" type="image/png" href="images/favicon.png" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/bootstrap.min.css')); ?> " />
        <link rel="stylesheet" href="<?php echo e(asset('assets/site.css')); ?>" />
        <link rel="stylesheet" href="<?php echo e(asset('assets/all.css')); ?>" />
    </head>
<body>
<div class="wrapper">

    <div class="header">
        <div class="container divLogo">
            <div class="row">
                <div class="col-sm-12" style="padding-left: 0 !important">
                    <img src="<?php echo e(asset('assets/UKVI Logo.jpg')); ?>" alt="companyLogo" class="imgLogo col-sm-2 float-left" />
                </div>
            </div>
        </div>
    </div>

    <div class="container body-container">
        <div>
            <?php if(session('success')): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?php echo e(session('success')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?php echo e(session('error')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
        </div>

        <div class="stepwizard clearfix">
            <div class="stepwizard-step">
                <a data-num="1" class="active" id="ConfirmationDetails-step" href="<?php echo e(url('/details/confirm-details')); ?>">Confirm Details<span class="arrow"></span></a>
            </div>
            <div class="stepwizard-step">
                <a data-num="2" class="" id="PaymentAmount-step" href="<?php echo e(route('payment.amount')); ?>">Payment Amount<span class="arrow"></span></a>
            </div>
            <div class="stepwizard-step">
                <a data-num="3" class="" id="PaymentDetails-step" href="<?php echo e(route('payment.details')); ?>">Payment Details<span class="arrow"></span></a>
            </div>
            <div class="stepwizard-step ">
                <a data-num="4" id="PaymentConfirmation-step" href="/Payment/Confirmation">Confirmation</a>
            </div>
        </div>

    <form action="<?php echo e(route('payment.submit')); ?>" id="payment-form" method="POST"> 
        <?php echo csrf_field(); ?>
        <div id="stripeToken"></div>
        <input type="hidden" name="amount" value="2.74" />
        <input type="hidden" name="user_id" value="<?php echo e($user_id); ?>" />
        <div class="text-center">
            <div class="row">
                <div class="col-md-6">
                    <h1 class="text-left fontHelveticaHeader">Payment Details</h1>
                </div>
                <div class="col-md-6">
                    <div id="cards"></div>
                </div>
            </div>

            <br />
            <br />

            <div class="text-left fontHelveticaParagraph">
                <p>We aim to respond to your email in five working days.</p>
                <br />
                <p>If you do not select 'submit' your enquiry will not be completed and you will not be charged. For more contact</p>
                <p>
                    options please visit
                    <a class="text-decoration-underline" style="color: #0055B7;" href="https://www.gov.uk/contact-ukvi-inside-outside-uk">https://www.gov.uk/contact-ukvi-inside-outside-uk</a>
                </p>

                <br />
                <br />

                <p>
                    Please enter details below.
                </p>

            </div>
        </div>
        <br />
        <div class="fontHelveticaParagraph">
            <p>
                <label class="required" for="CardHolderName">Card Holder Name</label><br />
                <input class="form-control text-box single-line" data-val="true" data-val-maxlength="The field Card Holder Name must be a string or array type with a maximum length of &#x27;50&#x27;." data-val-maxlength-max="50" data-val-regex="Please enter a card holder" data-val-regex-pattern="^([A-Za-z]&#x2B;[\s-&#x27;&#xE2;&#x20AC;&#x2DC;&#xE2;&#x20AC;&#x2122;&#xC2;&#xB4;&#xE2;&#x20AC;&#x153;&#xE2;&#x20AC;&#x9D;])*[A-Za-z]*$" data-val-required="The Card Holder Name field is required." id="CardHolderName" maxlength="50" name="card_holder_name" type="text" value="" />
                <span class="field-validation-valid" data-valmsg-for="CardHolderName" data-valmsg-replace="true"></span>
                <?php $__errorArgs = ['card_holder_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </p>
            <p>
                <label class="required" for="CardNumber">Card Number</label><br />
                <input class="form-control text-box single-line" data-val="true" data-val-maxlength="The field Card Number must be a string or array type with a maximum length of &#x27;16&#x27;." data-val-maxlength-max="16" data-val-regex="Please enter a valid card number" data-val-regex-pattern="^[0-9]{13,16}$" data-val-required="The Card Number field is required." id="CardNumber" maxlength="16" name="card_number" type="text" value="" />
                <span class="field-validation-valid" data-valmsg-for="CardNumber" data-valmsg-replace="true"></span>
                <?php $__errorArgs = ['card_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </p>

            <div class="row">
                <div class="col-md-8">
                    <div class="col-md-4 col-sm-3 col-6 float-left" style="padding-left: 0 !important">
                        <label for="ExpiryMonth">Expiry Date</label>
                        <br />
                        <input class="text-box single-line" data-val="true" data-val-maxlength="The field ExpiryMonth must be a string or array type with a maximum length of &#x27;2&#x27;." data-val-maxlength-max="2" data-val-regex="Please enter a valid expiry month" data-val-regex-pattern="^(0[1-9]|1[0-2])$" data-val-required="The Expiry Month is required" id="ExpiryMonth" maxlength="2" name="expiry_month" style="width:30px;" type="text" value="" />
                        <?php $__errorArgs = ['expiry_month'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <span class="sep">/</span>
                        <input class="text-box single-line" data-val="true" data-val-maxlength="The field ExpiryYear must be a string or array type with a maximum length of &#x27;2&#x27;." data-val-maxlength-max="2" data-val-regex="Please enter a valid expiry year" data-val-regex-pattern="^([0-9]{2})$" data-val-required="The Expiry Year is required" id="ExpiryYear" maxlength="2" name="expiry_year" style="width:30px;" type="text" value="" />
                        <?php $__errorArgs = ['expiry_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 col-sm-3 col-6 float-left">
                        <label class="required" for="Cvc" style="text-transform:uppercase">Cvc</label><br />
                        <input class="text-box single-line" data-val="true" data-val-maxlength="The field Cvc must be a string or array type with a maximum length of &#x27;4&#x27;." data-val-maxlength-max="4" data-val-regex="CVC must be either 3 or 4 digits." data-val-regex-pattern="^[0-9]{3,4}$" data-val-required="The Cvc field is required." id="Cvc" maxlength="4" name="cvc" style="width:50px;" type="text" value="" />
                        <i class="fa fa-question-circle" title="Please enter your card verification number. This number can usually be found on the back of your card and is the last three digits next to the signature." aria-hidden="true"></i>
                        <span class="field-validation-valid" data-valmsg-for="Cvc" data-valmsg-replace="true"></span>
                        <?php $__errorArgs = ['cvc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
            <br />
            <br />
            <p>
                <label for="Email">For an email payment receipt please provide an email address (Optional)</label><br />
                <input class="form-control text-box single-line" data-val="true" data-val-regex="Please enter a valid email" data-val-regex-pattern="^\w&#x2B;([-&#x2B;.&#x27;]\w&#x2B;)*@\w&#x2B;([-.]\w&#x2B;)*\.\w&#x2B;([-.]\w&#x2B;)*$" id="Email" name="Email" type="text" value="" />
                <span class="field-validation-valid" data-valmsg-for="Email" data-valmsg-replace="true"></span>
            </p>
        </div>
        <div id="securePaymentCardFlow">
        </div>

        <div id="payDetails" class="order-confirmation">
            <div class="padding">
                <div class="top clearfix row">
                    <div class="col-md-6 pull-left">CONFIRMATION</div>
                    <div class="col-md-6 pull-right">This is a secure SSL protected payment</div>
                </div>
                <div class="line clearfix row">
                    <div class="col-md-6 col-6 pull-left">Amount</div>
                    <div class="col-md-6 col-6 pull-right" style="text-align: end;font-size: 26px;font-weight: 600"><span id="amountWs" class="gbp"></span>2.74</div>
                </div>

            </div>
            <div id="payDetailsSubmitBtn">
                <button class="btn btn-success" id="submitbtn">Pay <span class="gbp"></span>2.74</button>
            </div>
        </div>
    </form>




<input name="__RequestVerificationToken" type="hidden" value="CfDJ8M_95A44e0pOvUqgfE4vO7aKhzt8iPw4KN3bkHgmVxsBOiMjiDmq0iUqKg81a10rBY_Ilpk3l-OZkrpoCMI8H5VWtCpoRRPlOnmooLNZc_h4DNQeED5ft8m3qeAjUrEfFVYCczfHD6BJKhP-MHQ3lDQ" /></form>


<script src="<?php echo e(asset('assets/jquery.min.js')); ?>"></script>

    </div>

    <footer>
        <div class="footerPosition">
            <div class="container">
                <div class="row">
                    <nav class="navbar navbar-expand-sm">
                        <div class="container">
                            <div class=" d-sm-inline-flex flex-sm-row-reverse" style="margin-left: -25px">
                                <ul class="navbar-nav flex-grow-1 text-decoration-underline">
                                    <li class="nav-item">
                                        <a class="nav-link text-dark" href="https://www.gov.uk/help/privacy-notice">Privacy</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-dark" href="https://www.gov.uk/help/cookies">Cookies</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-dark" href="https://www.gov.uk/help/accessibility-statement">Accessibility Statements</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link text-dark" href="https://www.gov.uk/help/terms-conditions">Terms and Conditions</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </nav>
                </div>
                <div class="row">
                    <div class="col-sm-3 footerProvider">
                        <h2>Powered by</h2>
                        <img src="<?php echo e(asset('assets/keyivr.png')); ?>" alt="powerLogo" /></div>
                </div>
            </div>
        </div>
    </footer>
</div>


<script type="text/javascript" src="https://js.stripe.com/v2/"></script>
<script>
    $(document).ready(function () {
        $('#payDetailsSubmitBtn').on('click', function(){
            // var stripe = Stripe('pk_test_51L2tMZKd4S1wsoet4Echxm69BYMGlBvFOSFp9qHPqIDhKBBbyKu9Evej4i92k44UWPtjoHZB45fcC3MrEI05uYs100bXIPgkEK');
            
            // Handle form submission
            var form = document.getElementById('payment-form');
            form.addEventListener('submit', function(event) {
            event.preventDefault();
            });


            Stripe.setPublishableKey('pk_test_51L2tMZKd4S1wsoet4Echxm69BYMGlBvFOSFp9qHPqIDhKBBbyKu9Evej4i92k44UWPtjoHZB45fcC3MrEI05uYs100bXIPgkEK');
            Stripe.createToken({
                number: $('#CardNumber').val(),
                cvc: $('.card-cvc').val(),
                exp_month: $('#ExpiryMonth').val(),
                exp_year: $('#ExpiryYear').val()
            }, stripeResponseHandler);

            /*------------------------------------------
            --------------------------------------------
            Stripe Response Handler
            --------------------------------------------
            --------------------------------------------*/
            function stripeResponseHandler(status, response) {
                if (response.error) {
                    $('.error')
                        .removeClass('hide')
                        .find('.alert')
                        .text(response.error.message);
                } else {
                    /* token contains id, last4, and card type */
                    var token = response['id'];
                    
                    $('#stripeToken').append("<input type='hidden' name='stripeToken' value='" + token + "'/>");
                    
                    setTimeout(function() {
                        document.getElementById('payment-form').submit();
                    }, 500);
                }
            }
        });
    });

</script>

<script src="<?php echo e(asset('assets/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/all.js')); ?>"></script>
<script src="<?php echo e(asset('assets/StepWizardSelection.js')); ?>"></script>
<script src="<?php echo e(asset('assets/script.js')); ?>"></script>
<script src="<?php echo e(asset('assets/jquery.validate.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/jquery.validate.unobtrusive.min.js')); ?>"></script>

</body>
</html><?php /**PATH G:\wamp64\www\personal\visa_payment\resources\views/payment-details.blade.php ENDPATH**/ ?>